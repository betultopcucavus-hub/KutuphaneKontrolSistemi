﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Core
{
    public class Kitap
    {
        public string Ad { get; set; }
        public bool OduncteMi { get; set; }
        public string AlanKisi { get; set; }
        public DateTime? OduncTarihi { get; set; }

        public Kitap() { }
        public Kitap(string ad)
        {
            Ad = ad;
            OduncteMi = false;
        }
        public bool GeciktiMi(int gunSiniri)
        {
            if (!OduncteMi || !OduncTarihi.HasValue) return false;
            int gun = (DateTime.Now.Date - OduncTarihi.Value.Date).Days;
            return gun > gunSiniri;
        }
    }
}
