﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;


namespace Kutuphane.Core
{
    public static class DosyaOkumaYazma
    {
        // format : Ad| OOduncteMi|AlanKisi|OduncTarihi(ISO)

        public static List<Kitap> Oku(string dosyaYolu)
        {
            var liste = new List<Kitap> ();
            if (!File.Exists(dosyaYolu)) return liste;

            var satirlar = File.ReadAllLines(dosyaYolu, Encoding.UTF8);

            foreach (var raw in satirlar)
            {
                var line = raw?.Trim();
                if(string.IsNullOrWhiteSpace(line)) continue;

                var p = line.Split('|');
                if(p.Length < 2 ) continue;

                string ad = p[0].Trim();
                if(string.IsNullOrEmpty(ad) ) continue;

                bool oduncteMi;
                if (!bool.TryParse(p[1].Trim(), out oduncteMi) ) continue;

                string alanKisi = (p.Length >= 3) ? p[2].Trim() : "";
                DateTime? oduncTarihi = null;

                if( p.Length >= 4 ) 
                {
                    DateTime dt;
                    if (DateTime.TryParse(p[3].Trim(), CultureInfo.InvariantCulture,
                            DateTimeStyles.AssumeLocal, out dt))
                        oduncTarihi = dt;
                }

                liste.Add(new Kitap
                {
                    Ad = ad,
                    OduncteMi = oduncteMi,
                    AlanKisi = alanKisi,
                    OduncTarihi =oduncTarihi
                });

            }
            return liste;
        }
        public static void Yaz (string dosyaYolu, List<Kitap>kitaplar)
        {
            var lines = new List<string>();

            foreach (var k in kitaplar)
            {
                string ad = (k.Ad ?? "").Trim();
                if(string.IsNullOrWhiteSpace(ad)) continue;

                string alan = (k.AlanKisi ?? "").Trim();
                string tarih = k.OduncTarihi.HasValue
                    ? k.OduncTarihi.Value.ToString("o", CultureInfo.InvariantCulture)
                    : "";
                lines.Add($"{ad}|{k.OduncteMi}|{alan}|{tarih}");
            }
            File.WriteAllLines(dosyaYolu, lines, Encoding.UTF8);
        }
    }
}
