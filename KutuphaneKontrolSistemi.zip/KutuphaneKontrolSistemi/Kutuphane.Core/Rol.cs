﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Core
{
    public enum Rol
    {
        User =1,
        Admin =2
    }
}
