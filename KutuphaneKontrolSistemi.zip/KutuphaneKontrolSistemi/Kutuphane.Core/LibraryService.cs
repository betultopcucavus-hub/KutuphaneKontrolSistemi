﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Core
{
    public class LibraryService
    {

        private readonly List<Kitap> _kitaplar = new List<Kitap>();
        private readonly string _dosyaYolu;
        private readonly string _logDosyaYolu;

        public int GecikmeGunSiniri { get; set; } = 30;
        public LibraryService(string dosyaYolu)
        {
            _dosyaYolu = dosyaYolu;
            _logDosyaYolu = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs.txt");
        }

        // DIŞARIDAN SADECE KOPYA LİSTE VERELİM (GÜVENLİ OLMASI İÇİN)
        public List<Kitap> GetAll()
        {
            return _kitaplar
                .OrderBy(k => k.OduncteMi) // Rafta Önce
                .ThenBy(k => k.Ad, StringComparer.CurrentCultureIgnoreCase)
                .Select(k => new Kitap
                {
                    Ad = k.Ad,
                    OduncteMi= k.OduncteMi,
                    AlanKisi = k.AlanKisi,
                    OduncTarihi= k.OduncTarihi
                })
                .ToList();
        }

        public void BaslangicYukleVeyaOlustur()
        {
            Yukle();
            if (_kitaplar.Count == 0)
            {
                VarsayilanlariKur();
                Kaydet();
                LogIslemleri.LogEkle(_logDosyaYolu, "SISTEM", "Varsayılan kitaplar oluşturuldu");
            }
        }

        private void VarsayilanlariKur()
        {
            _kitaplar.Clear();
            _kitaplar.Add(new Kitap("Sefiller"));
            _kitaplar.Add(new Kitap("1984"));
            _kitaplar.Add(new Kitap("Kürk Mantolu Madonna"));
            _kitaplar.Add(new Kitap("Suç ve Ceza"));
            _kitaplar.Add(new Kitap("Simyacı"));
            _kitaplar.Add(new Kitap("Tutunamayanlar"));
            _kitaplar.Add(new Kitap("Korkusuzlar"));
        }

        public bool KitapEkle(string kitapAd, out string mesaj)
        {
            mesaj = "";

            if (string.IsNullOrWhiteSpace(kitapAd))
            {
                mesaj = "Kitap adı boş olamaz!";
                return false;
            }

            kitapAd = kitapAd.Trim();

            bool varMi = _kitaplar.Any(k => k.Ad.Equals(kitapAd, StringComparison.CurrentCultureIgnoreCase));
            if (varMi)
            {
                mesaj = "Bu kitap zaten kayıtlı!";
                return false;
            }

            _kitaplar.Add(new Kitap(kitapAd));
            Kaydet();
            LogIslemleri.LogEkle(_logDosyaYolu, "EKLE", kitapAd);
            mesaj = " Kitap eklendi!" + kitapAd;
            return true;
        }

        public bool KitapSil(string ad, out string mesaj)
        {
            mesaj = "";

            var kitap = KitapBul(ad);
            if (kitap == null)
            {
                mesaj = "Kitap bulunamadı!" + ad;
                return false;
            }
            if (kitap.OduncteMi)
            {
                mesaj = "Kitap ödünçte olduğu için silinemez!" + kitap.Ad;
                return false;
            }

            _kitaplar.Remove(kitap);
            Kaydet();
            LogIslemleri.LogEkle(_logDosyaYolu, "SİL", kitap.Ad);
            mesaj = " Kitap Silindi!" + kitap.Ad;
            return true;
        }

        public bool OduncAl(string kitapAdi, string alanKisi, out string mesaj)
        {
            mesaj = "";

            var kitap = KitapBul(kitapAdi);
            if (kitap == null)
            {
                mesaj = "Kitap bulunamadı! :" + kitapAdi;
                return false;
            }
            if (kitap.OduncteMi)
            {
                mesaj = "Bu kitap zaten ödünçte!:" + kitap.Ad;
                return false;
            }

            if (string.IsNullOrWhiteSpace(alanKisi))
                alanKisi = "Bilinmiyor";

            kitap.OduncteMi = true;
            kitap.AlanKisi = alanKisi.Trim();
            kitap.OduncTarihi = DateTime.Now;

            Kaydet();
            LogIslemleri.LogEkle(_logDosyaYolu, "ODUNC", $"{kitap.Ad} → {kitap.AlanKisi}");
            mesaj = $"Ödünç verildi: {kitap.Ad}";
            return true;
        }

        public bool IadeEt(string kitapAdi, out string mesaj)
        {
            mesaj = "";

            var kitap = KitapBul(kitapAdi);
            if (kitap == null)
            {
                mesaj = "Kitap bulunamadı!" + kitapAdi;
                return false;
            }

            if (!kitap.OduncteMi)
            {
                mesaj = " Bu kitap zaten rafta!:" + kitap.Ad;
                return false;
            }

            string kimdi = kitap.AlanKisi;
            kitap.OduncteMi = false;
            kitap.AlanKisi = "";
            kitap.OduncTarihi = null;

            Kaydet();
            LogIslemleri.LogEkle(_logDosyaYolu, "IADE", $"{kitap.Ad} (alan: {kimdi})");
            mesaj = "İade Alındı:" + kitap.Ad;
            return true;
        }

        public void VerileriSifirla()
        {
            // VarsayilanlariKur();
            Kaydet();
            LogIslemleri.LogEkle(_logDosyaYolu, "SIFIRLA", "Veriler sıfırlandı!");
        }        
    
        public (int toplam, int rafta, int oduncte, int geciken) Ozet()
        {
            int toplam = _kitaplar.Count;
            int rafta = _kitaplar.Count(k => !k.OduncteMi);
            int oduncte = _kitaplar.Count(k => k.OduncteMi);
            int geciken = _kitaplar.Count(k => k.GeciktiMi(GecikmeGunSiniri));
            return (toplam, rafta, oduncte, geciken);
        }

        public List<string> SonLoglariGetir( int adet =10)
        {
            return LogIslemleri.SonLoglariGetir(_logDosyaYolu, adet);
        }

        private void Kaydet()
        {
            DosyaOkumaYazma.Yaz(_dosyaYolu, _kitaplar);
        }
        private void Yukle()
        {
            _kitaplar.Clear();
            _kitaplar.AddRange(DosyaOkumaYazma.Oku(_dosyaYolu));            
        }

        private Kitap KitapBul(string giris)
        {
            if (string.IsNullOrWhiteSpace(giris)) return null;
            string t = giris.Trim();

            return _kitaplar.FirstOrDefault(k => k.Ad.Equals(t, StringComparison.CurrentCultureIgnoreCase));
        }
    }
}
          



    
