﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Core
{
    public static class LogIslemleri
    {
        //Format : yyy-MMM-dd HH:mm:ss | AKSIYON | DETAY
        public static void LogEkle(string logDosyaYolu, string aksiyon, string detay)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(logDosyaYolu) ?? ".");
                string line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {aksiyon} | {detay}";
                File.AppendAllText(logDosyaYolu, line + Environment.NewLine, Encoding.UTF8);

                // dosyamız büyümesin diye
                Kirp(logDosyaYolu, 500);
            }
            catch { }
        }
        public static List<string> SonLoglariGetir(string logDosyaYolu, int adet = 10)
        {
            try
            {
                if (!File.Exists(logDosyaYolu)) return new List<string>();

                var lines = File.ReadAllLines(logDosyaYolu, Encoding.UTF8)
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .ToList();

                int bas = Math.Max(0, lines.Count - adet);
                return lines.Skip(bas).ToList();                        
            }
            catch
            {
                return new List<string>();
            }
        }
        private static void Kirp(string logDosyaYolu, int maxSatir)
        {
            try
            {
                var lines = File.ReadAllLines(logDosyaYolu, Encoding.UTF8).ToList();
                if (lines.Count <= maxSatir) return;

                lines= lines.Skip(lines.Count - maxSatir).ToList();
                File.WriteAllLines(logDosyaYolu, lines, Encoding.UTF8);
            }
            catch { }
        }
    }
}
