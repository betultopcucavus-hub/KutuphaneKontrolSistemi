﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace Kutuphane_Denemesi1
{
    internal class Kitap
    {
        public string Ad { get; set; }
        public bool OduncteMi { get; set; }

        public string AlanKisi { get; set; } = "";
        public DateTime? OduncTarihi { get; set; }

        public Kitap(string ad)
        {
            Ad = ad;
            OduncteMi = false;
        }

        public bool GeciktiMi(int gunSiniri)
        {
            if (!OduncteMi || !OduncTarihi.HasValue) return false;
            int gun = (DateTime.Now.Date - OduncTarihi.Value.Date).Days;
            return gun > gunSiniri;
        }
    }

    internal class Program
    {
        // ===== VERİ =====
        static List<Kitap> kitaplar = new List<Kitap>();

        // ==== LOGLAR DEĞİŞKENİ ======00
        static List<string> loglar = new List<string>();

        // Dosyalar
        static string dosyaYolu = Path.Combine(AppContext.BaseDirectory, "kitapla.txt");
        static string logDosyaYolu = Path.Combine(AppContext.BaseDirectory, "loglar.txt");

        // Admin
        static string yoneticiSifre = "9999";
        static int gecikmeGunSiniri = 30;

        enum Rol { User = 1, Admin = 2 }
        static Rol aktifRol = Rol.User;

        // ===== LOG EKLE =====
        static void LogEkle(string mesaj)
        {
            string satir = $"{DateTime.Now:dd.MM.yyyy HH:mm} | {mesaj}";
            loglar.Add(satir);

            // PROGRAM KAPANSA BİLE DURSUN DİYE dosyaya ekle (kalıcı olsun)
            File.AppendAllText(logDosyaYolu, satir + Environment.NewLine, Encoding.UTF8);
            // list şişmesin diye
            if (loglar.Count > 200)
                loglar.RemoveAt(0);
        
            // dosya çok büyümesin diye (örnek: 500 satır üstü kırp)
            try
            {
                var tum = File.ReadAllLines(logDosyaYolu, Encoding.UTF8).ToList();
                if (tum.Count > 500)
                {
                    tum = tum.Skip(tum.Count - 500).ToList();
                    File.WriteAllLines(logDosyaYolu, tum, Encoding.UTF8);
                }
            }
            catch { }
        }

        static void LoglariGoster()
        {
            if( aktifRol !=Rol.Admin)
            {
                MesajGoster("Bu ekran sadece yönetici içindir!", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("=== SON İŞLEMLER ===");
            Console.ResetColor();
            Console.WriteLine("--------------------");

            if (!File.Exists(logDosyaYolu))
            {
                MesajGoster("Henüz log yok.", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            var loglar = File.ReadAllLines(logDosyaYolu, Encoding.UTF8)
                               .Where(x => !string.IsNullOrWhiteSpace(x))
                               .ToList();

            if (loglar.Count == 0)
            {
                MesajGoster("Henüz log yok.", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            int baslangic = Math.Max(0, loglar.Count - 10);
            for (int i = baslangic; i < loglar.Count; i++)
                Console.WriteLine(" - " + loglar[i]);

            Bekle();
        }

        // ===== UI =====
        static void MesajGoster(string mesaj, ConsoleColor renk)
        {
            Console.ForegroundColor = renk;
            Console.WriteLine(mesaj);
            Console.ResetColor();
        }

        // ====== BEKLE =========
        static void Bekle()
        {
            Console.WriteLine();
            Console.WriteLine("Devam etmek için ENTER...");
            Console.ReadLine();
        }

        // ======= GECERLİ SAYIYI ALMAK İÇİN ==========
        static int GecerliSayiAl(string mesaj)
        {
            while (true)
            {
                Console.Write(mesaj);
                string giris = Console.ReadLine();

                int sayi;
                if (int.TryParse(giris, out sayi))
                    return sayi;

                MesajGoster("Lütfen sadece sayı giriniz!", ConsoleColor.Red);
            }
        }

        // ===== DOSYA =====
        static void DosyayaKaydet()
        {
            using (var writer = new StreamWriter(dosyaYolu, false, Encoding.UTF8))
            {
                foreach (var k in kitaplar.OrderBy(x => x.OduncteMi)
                                          .ThenBy(x => x.Ad, StringComparer.CurrentCultureIgnoreCase))
                {
                    string tarih = k.OduncTarihi.HasValue ? k.OduncTarihi.Value.ToString("yyyy-MM-dd") : "";
                    writer.WriteLine($"{k.Ad}|{k.OduncteMi}|{k.AlanKisi}|{tarih}");
                }
            }
        }

        // ====== DOSYADAN YÜKLEMEK İÇİN =======
        static void DosyadanYukle()
        {
            kitaplar.Clear();

            if (!File.Exists(dosyaYolu))
                return;

            foreach (var satir in File.ReadAllLines(dosyaYolu, Encoding.UTF8))
            {
                if (string.IsNullOrWhiteSpace(satir)) continue;

                var p = satir.Split('|');
                if (p.Length < 2) continue;

                string ad = p[0].Trim();
                if (string.IsNullOrEmpty(ad)) continue;

                bool oduncteMi;
                if (!bool.TryParse(p[1].Trim(), out oduncteMi)) continue;

                string alanKisi = (p.Length >= 3) ? p[2].Trim() : "";
                DateTime? oduncTarihi = null;

                if (p.Length >= 4)
                {
                    DateTime dt;
                    if (DateTime.TryParse(p[3].Trim(), out dt))
                        oduncTarihi = dt;
                }

                var k = new Kitap(ad);
                k.OduncteMi = oduncteMi;
                k.AlanKisi = alanKisi;
                k.OduncTarihi = oduncTarihi;

                kitaplar.Add(k);
            }
        }

        static void BaslangicYukleVeyaOlustur()
        {
            if (File.Exists(dosyaYolu))
                DosyadanYukle();

            if (kitaplar.Count == 0)
            {
                kitaplar.Add(new Kitap("Sefiller"));
                kitaplar.Add(new Kitap("Kürk Mantolu Madonna"));
                kitaplar.Add(new Kitap("1984"));
                DosyayaKaydet();
            }
        }

        // ===== KİTAP BUL =====
        static Kitap KitapBul(string giris)
        {
            if (string.IsNullOrWhiteSpace(giris)) return null;
            string aranan = giris.Trim();

            return kitaplar.FirstOrDefault(k =>
                k.Ad.Equals(aranan, StringComparison.CurrentCultureIgnoreCase));
        }

        // ===== ROL GİRİŞ =====
        static void RolIleGiris()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("****** GİRİŞ ******");
            Console.ResetColor();

            Console.WriteLine("1 - Kullanıcı");
            Console.WriteLine("2 - Yönetici");
            Console.WriteLine("--------------------");

            int secim = GecerliSayiAl("Rol seçiniz: ");

            if (secim == 1)
            {
                aktifRol = Rol.User;
                MesajGoster("Kullanıcı modu açıldı.", ConsoleColor.Cyan);
                System.Threading.Thread.Sleep(500);
                return;
            }

            if (secim == 2)
            {
                if (YoneticiGiris())
                {
                    aktifRol = Rol.Admin;
                    MesajGoster("Yönetici modu açıldı.", ConsoleColor.Cyan);
                    System.Threading.Thread.Sleep(500);
                }
                else
                {
                    aktifRol = Rol.User;
                    MesajGoster("Yönetici girişi başarısız. Kullanıcı moduna devam.", ConsoleColor.Yellow);
                    System.Threading.Thread.Sleep(700);
                }
                return;
            }

            aktifRol = Rol.User;
            MesajGoster("Geçersiz seçim. Kullanıcı moduna devam.", ConsoleColor.Yellow);
            System.Threading.Thread.Sleep(700);
        }

        // ===== MENÜ NUMARALARI =====
        // Menü kaymasın diye: numaraları burada hesaplıyoruz
        static int MenuNo_AdminPanel() => (aktifRol == Rol.Admin) ? 4 : -1;
        static int MenuNo_SonIslemler() => (aktifRol == Rol.Admin) ? 5 : -1;
        static int MenuNo_Cikis() => (aktifRol == Rol.Admin) ? 6 : 4;

        // ======= MENÜ GöSTER =======
        static void MenuGoster()
        {
            Console.Clear();

            int rafta = kitaplar.Count(x => !x.OduncteMi);
            int oduncte = kitaplar.Count(x => x.OduncteMi);
            int geciken = kitaplar.Count(x => x.GeciktiMi(gecikmeGunSiniri));

            var m = MenuNumaralari();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("===== KÜTÜPHANE =====");
            Console.ResetColor();

            Console.WriteLine($"Mod: {aktifRol}");
            Console.WriteLine($"Toplam: {kitaplar.Count} | Rafta: {rafta} | Ödünçte: {oduncte} | Geciken: {geciken}");
            Console.WriteLine("---------------------");

            Console.WriteLine($"{m.Listele} - Kitapları Listele");
            Console.WriteLine($"{m.Odunc} - Ödünç Al");
            Console.WriteLine($"{m.Iade} - İade Et");

            if (aktifRol == Rol.Admin)
            { 
            Console.WriteLine($"{m.AdminPanel.Value} - Yönetici Paneli (Kitap Ekle/Sil)");
            Console.WriteLine($"{m.SonIslemler.Value} - Son İşlemler");
            }

            Console.WriteLine($"{m.Cikis} - Çıkış");
            Console.WriteLine("---------------------");
        }

        static int MenuSeciminiAl()
        {
            return GecerliSayiAl("Seçiminiz: ");
        }

        // logları Dosyadan yuklemek için
        static void LoglariDosyadanYukle()
        {
            loglar.Clear();

            if (!File.Exists(logDosyaYolu))
                return;
            foreach( var satir in File.ReadAllLines(logDosyaYolu ,Encoding.UTF8))
            {
                if (!string.IsNullOrWhiteSpace(satir))
                    loglar.Add(satir.Trim());
            }
            // yine son 200
            if (loglar.Count > 200)
                loglar = loglar.Skip(loglar.Count - 200).ToList();
        }

        // menu numaralarını tek yerden hesaplamak için
        struct MenuNo
        {
            public int Listele;
            public int Odunc;
            public int Iade;
            public int? AdminPanel; // admin değilse null
            public int? SonIslemler; // admin değilse null
            public int Cikis;
        }

        static MenuNo MenuNumaralari()
        {
            //Her iki rolde ortaklar
            int no = 1;

            var m = new MenuNo();
            m.Listele   = no++;  //1
            m.Odunc     = no++;  //2
            m.Iade      = no++;  //3

            if(aktifRol == Rol.Admin)
            {
                m.AdminPanel    = no++;   //4
                m.SonIslemler   = no++;   //5
                m.Cikis         = no++;   //6
            }
            else
            {
                m.AdminPanel    = null;
                m.SonIslemler   = null;
                m.Cikis = no++; //4
            }
            return m;
        }

        // ===== MAIN =====
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            BaslangicYukleVeyaOlustur();
            LoglariDosyadanYukle();
            RolIleGiris();

            int secim;
            do
            {
                MenuGoster();
                secim = MenuSeciminiAl();
                IslemYap(secim);
            }
            while (secim != MenuNo_Cikis());
        }

        // ===== İŞLEM =====
        static void IslemYap(int secim)
        {
            var m = MenuNumaralari();
           
            // çıkış
            if(secim == m.Cikis)
            {
                DosyayaKaydet();
                // LogEkle("ÇIKIŞ | Pragram Kapatıldı!");
                MesajGoster("Çıkış yapılıyor...!", ConsoleColor.Yellow);
                Thread.Sleep(500);
                return;
            }

            if (secim == m.Listele)
            { KitaplariListele(aktifRol == Rol.Admin);
                return;
            }

            if(secim == m.Odunc)
            {
                OduncAl();
                return;
            }

            if (secim == m.Iade)
            {
                IadeEt();
                return;
            }

            // admin özel alanlar

            if (aktifRol == Rol.Admin && m.AdminPanel.HasValue && secim == m.AdminPanel.Value)
            {
                YoneticiPaneli();
                return;
            }

            if (aktifRol == Rol.Admin && m.SonIslemler.HasValue && secim == m.SonIslemler.Value)
            {
                LoglariGoster(); // sadecce admin görsün istiyorsan burda kalacak..
                return;
            }
                         
        }
        static void GecersizSecim()
        {
            MesajGoster("Geçersi Seçim!", ConsoleColor.Red);
            Bekle();
        }


        // ===== 1) LİSTELE =====
        static void KitaplariListele(bool yoneticiModu)
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=== KİTAPLAR ===");
            Console.ResetColor();

            var raftakiler = kitaplar.Where(k => !k.OduncteMi)
                                     .OrderBy(k => k.Ad, StringComparer.CurrentCultureIgnoreCase)
                                     .ToList();

            var odunctekiler = kitaplar.Where(k => k.OduncteMi)
                                       .OrderBy(k => k.Ad, StringComparer.CurrentCultureIgnoreCase)
                                       .ToList();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine($"RAFTA ({raftakiler.Count})");
            Console.ResetColor();
            Console.WriteLine("--------------------");
            foreach (var k in raftakiler)
                Console.WriteLine(" - " + k.Ad);

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine($"ÖDÜNÇTE ({odunctekiler.Count})");
            Console.ResetColor();
            Console.WriteLine("--------------------");

            foreach (var k in odunctekiler)
            {
                string kisi = yoneticiModu
                    ? (string.IsNullOrWhiteSpace(k.AlanKisi) ? "Bilinmiyor" : k.AlanKisi)
                    : "****";

                int gun = k.OduncTarihi.HasValue ? (DateTime.Now.Date - k.OduncTarihi.Value.Date).Days : 0;

                if (k.GeciktiMi(gecikmeGunSiniri))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($" - {k.Ad} → {kisi} | {gun} gün (GECİKTİ)");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($" - {k.Ad} → {kisi} | {gun} gün");
                    Console.ResetColor();
                }
            }

            Bekle();
        }

        // ===== 2) ÖDÜNÇ =====
        static void OduncAl()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("=== ÖDÜNÇ AL ===");
            Console.ResetColor();

            Console.Write("Kitap adı: ");
            string giris = Console.ReadLine();

            var kitap = KitapBul(giris);
            if (kitap == null)
            {
                MesajGoster("Kitap bulunamadı!", ConsoleColor.Red);
                Bekle();
                return;
            }
            if (kitap.OduncteMi)
            {
                MesajGoster("Bu kitap zaten ödünçte!", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            Console.Write("Alan kişi adı: ");
            string kisi = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(kisi)) kisi = "Bilinmiyor";

            kitap.OduncteMi = true;
            kitap.AlanKisi = kisi.Trim();
            kitap.OduncTarihi = DateTime.Now;

            DosyayaKaydet();
            LogEkle($"ÖDÜNÇ | {kitap.Ad} → {kitap.AlanKisi}");

            MesajGoster("Ödünç verildi:" + kitap.Ad, ConsoleColor.Green);
            Bekle();
        }

        // ===== 3) İADE =====
        static void IadeEt()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("=== İADE ET ===");
            Console.ResetColor();

            Console.Write("Kitap adı: ");
            string giris = Console.ReadLine();

            var kitap = KitapBul(giris);
            if (kitap == null)
            {
                MesajGoster("Kitap bulunamadı!", ConsoleColor.Red);
                Bekle();
                return;
            }
            if (!kitap.OduncteMi)
            {
                MesajGoster("Bu kitap zaten rafta!", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            kitap.OduncteMi = false;
            kitap.AlanKisi = "";
            kitap.OduncTarihi = null;

            DosyayaKaydet();
            LogEkle($"İADE | {kitap.Ad}");

            MesajGoster("İade alındı: " + kitap.Ad, ConsoleColor.Green);
            Bekle();
        }

        // ===== YÖNETİCİ =====
        static bool YoneticiGiris()
        {
            int hak = 3;

            while (hak > 0)
            {
                Console.Write("Yönetici şifresi: ");
                string giris = Console.ReadLine();

                if (giris == yoneticiSifre)
                {
                    MesajGoster("Giriş başarılı!", ConsoleColor.Green);
                    return true;
                }

                hak--;
                MesajGoster("Şifre yanlış! Kalan hak: " + hak, ConsoleColor.Red);
            }

            return false;
        }

        // ====== YÖNETİCİ PANALEİ ===========0
        static void YoneticiPaneli()
        {
            Console.Clear();

            // zaten admin roldeyiz ama yine de şifre istiyorsan açık kalsın
            if (!YoneticiGiris())
            {
                MesajGoster("Yetkisiz erişim. Menüye dönülüyor.", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("=== YÖNETİCİ PANELİ ===");
                Console.ResetColor();

                Console.WriteLine("1 - Kitap Ekle");
                Console.WriteLine("2 - Kitap Sil (Ödünçteyse silmez)");
                Console.WriteLine("3 - Gecikenleri Listele");
                Console.WriteLine("4 - Verileri Sıfırla");
                Console.WriteLine("5 - Ana Menüye Dön");
                Console.WriteLine("-----------------------");

                int secim = GecerliSayiAl("Seçiminiz: ");

                if (secim == 1) { KitapEkle(); continue; }
                if (secim == 2) { KitapSil(); continue; }
                if (secim == 3) { GecikenleriListele(); continue; }
                if (secim == 4) { VerileriSifirla(); continue; }
                if (secim == 5) return;

                MesajGoster("Geçersiz seçim!", ConsoleColor.Yellow);
                Bekle();
            }
        }

        // ======= KİTAP EKLE ==========0
        static void KitapEkle()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("=== KİTAP EKLE ===");
            Console.ResetColor();

            Console.Write("Kitap adı: ");
            string ad = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(ad))
            {
                MesajGoster("Kitap adı boş olamaz!", ConsoleColor.Red);
                Bekle();
                return;
            }

            ad = ad.Trim();

            bool varMi = kitaplar.Any(k => k.Ad.Equals(ad, StringComparison.CurrentCultureIgnoreCase));
            if (varMi)
            {
                MesajGoster("Bu kitap zaten kayıtlı!", ConsoleColor.Yellow);
                Bekle();
                return;
            }

            kitaplar.Add(new Kitap(ad));
            DosyayaKaydet();
            LogEkle($"ADMIN | Kitap eklendi: {ad}");

            MesajGoster("Eklendi: " + ad, ConsoleColor.Green);
            Bekle();
        }

        // ======== KİTAP SİL ==========0
        static void KitapSil()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("=== KİTAP SİL ===");
            Console.ResetColor();

            Console.Write("Silinecek kitap adı: ");
            string giris = Console.ReadLine();

            var kitap = KitapBul(giris);
            if (kitap == null)
            {
                MesajGoster("Kitap bulunamadı!", ConsoleColor.Red);
                Bekle();
                return;
            }

            if (kitap.OduncteMi)
            {
                MesajGoster("Bu kitap ödünçte olduğu için silinemez!", ConsoleColor.Red);
                Bekle();
                return;
            }

            kitaplar.Remove(kitap);
            DosyayaKaydet();
            LogEkle($"ADMIN | Kitap silindi: {kitap.Ad}");

            MesajGoster("Silindi: " + kitap.Ad, ConsoleColor.Green);
            Bekle();
        }

        // ==== GECİKENLERİ LİSTELE ===========0
        static void GecikenleriListele()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("=== GECİKENLER ===");
            Console.ResetColor();

            Console.WriteLine("------------------");

            var gecikenler = kitaplar.Where(k => k.GeciktiMi(gecikmeGunSiniri))
                                     .OrderByDescending(k => (DateTime.Now.Date - k.OduncTarihi.Value.Date).Days)
                                     .ToList();

            if (gecikenler.Count == 0)
            {
                MesajGoster("Geciken kitap yok.", ConsoleColor.Green);
                Bekle();
                return;
            }

            Console.ForegroundColor = ConsoleColor.Red;
            foreach (var k in gecikenler)
            {
                string kisi = string.IsNullOrWhiteSpace(k.AlanKisi) ? "Bilinmiyor" : k.AlanKisi;
                int gun = (DateTime.Now.Date - k.OduncTarihi.Value.Date).Days;
                Console.WriteLine($" - {k.Ad} → {kisi} | {gun} gün (GECİKTİ)");
            }
            Console.ResetColor();

            Bekle();
        }

        // ========== VERİLERİ SIFIRLA ============0
        static void VerileriSifirla()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.WriteLine("=== VERİLERİ SIFIRLA ===");
            Console.ResetColor();

            kitaplar.Clear();

            if (File.Exists(dosyaYolu))
                File.Delete(dosyaYolu);

            kitaplar.Add(new Kitap("Sefiller"));
            kitaplar.Add(new Kitap("Kürk Mantolu Madonna"));
            kitaplar.Add(new Kitap("1984"));

            DosyayaKaydet();
            LogEkle("ADMIN | Veriler sıfırlandı");

            MesajGoster("Sıfırlandı. Varsayılan kitaplar kuruldu.", ConsoleColor.Cyan);
            Bekle();
        }
    }
}
