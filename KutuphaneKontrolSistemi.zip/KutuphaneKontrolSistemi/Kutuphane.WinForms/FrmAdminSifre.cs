﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutuphane.WinForms
{
    public partial class FrmAdminSifre : Form
    {
        public string GirilenSifre { get; set; }
        public FrmAdminSifre()
        {
            InitializeComponent();
        }

        private void FrmAdminSifre_Load(object sender, EventArgs e)
        {
            txtSifre.Focus(); //form açılır açılmaz şifre aktif olması için
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            GirilenSifre = txtSifre.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
