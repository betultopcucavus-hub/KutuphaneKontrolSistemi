﻿namespace Kutuphane.WinForms
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblToplam = new System.Windows.Forms.Label();
            this.lblRafta = new System.Windows.Forms.Label();
            this.lblOduncte = new System.Windows.Forms.Label();
            this.lblGeciken = new System.Windows.Forms.Label();
            this.dgvKitaplar = new System.Windows.Forms.DataGridView();
            this.lblMod = new System.Windows.Forms.Label();
            this.btnKitapEkle = new System.Windows.Forms.Button();
            this.btnKitapSil = new System.Windows.Forms.Button();
            this.btnVerileriSifirla = new System.Windows.Forms.Button();
            this.btnSonIslemler = new System.Windows.Forms.Button();
            this.grpRol = new System.Windows.Forms.GroupBox();
            this.rbYonetici = new System.Windows.Forms.RadioButton();
            this.rbKullanici = new System.Windows.Forms.RadioButton();
            this.txtKitapAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblToplamText = new System.Windows.Forms.Label();
            this.lblRaftaText = new System.Windows.Forms.Label();
            this.lblOduncteText = new System.Windows.Forms.Label();
            this.lblGecikmisText = new System.Windows.Forms.Label();
            this.bgOzet = new System.Windows.Forms.GroupBox();
            this.tlpOzet = new System.Windows.Forms.TableLayoutPanel();
            this.pnlToplam = new System.Windows.Forms.Panel();
            this.pnlGecikmis = new System.Windows.Forms.Panel();
            this.pnlRafta = new System.Windows.Forms.Panel();
            this.pnlOdunc = new System.Windows.Forms.Panel();
            this.btnIadeEt = new System.Windows.Forms.Button();
            this.btnListele = new System.Windows.Forms.Button();
            this.btnOduncAl = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grbYoneticiLinkleri = new System.Windows.Forms.GroupBox();
            this.txtAra = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKitaplar)).BeginInit();
            this.grpRol.SuspendLayout();
            this.bgOzet.SuspendLayout();
            this.tlpOzet.SuspendLayout();
            this.pnlToplam.SuspendLayout();
            this.pnlGecikmis.SuspendLayout();
            this.pnlRafta.SuspendLayout();
            this.pnlOdunc.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grbYoneticiLinkleri.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblToplam
            // 
            this.lblToplam.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblToplam.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplam.ForeColor = System.Drawing.Color.Black;
            this.lblToplam.Location = new System.Drawing.Point(0, 18);
            this.lblToplam.MaximumSize = new System.Drawing.Size(0, 16);
            this.lblToplam.MinimumSize = new System.Drawing.Size(0, 20);
            this.lblToplam.Name = "lblToplam";
            this.lblToplam.Size = new System.Drawing.Size(180, 20);
            this.lblToplam.TabIndex = 2;
            this.lblToplam.Text = "0";
            this.lblToplam.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRafta
            // 
            this.lblRafta.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblRafta.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRafta.ForeColor = System.Drawing.Color.Black;
            this.lblRafta.Location = new System.Drawing.Point(0, 18);
            this.lblRafta.MaximumSize = new System.Drawing.Size(0, 16);
            this.lblRafta.MinimumSize = new System.Drawing.Size(0, 20);
            this.lblRafta.Name = "lblRafta";
            this.lblRafta.Size = new System.Drawing.Size(180, 20);
            this.lblRafta.TabIndex = 3;
            this.lblRafta.Text = "0";
            this.lblRafta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOduncte
            // 
            this.lblOduncte.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblOduncte.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOduncte.ForeColor = System.Drawing.Color.Black;
            this.lblOduncte.Location = new System.Drawing.Point(0, 18);
            this.lblOduncte.MaximumSize = new System.Drawing.Size(0, 16);
            this.lblOduncte.MinimumSize = new System.Drawing.Size(0, 20);
            this.lblOduncte.Name = "lblOduncte";
            this.lblOduncte.Size = new System.Drawing.Size(180, 20);
            this.lblOduncte.TabIndex = 4;
            this.lblOduncte.Text = "0";
            this.lblOduncte.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGeciken
            // 
            this.lblGeciken.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblGeciken.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGeciken.ForeColor = System.Drawing.Color.Black;
            this.lblGeciken.Location = new System.Drawing.Point(0, 18);
            this.lblGeciken.MaximumSize = new System.Drawing.Size(0, 16);
            this.lblGeciken.MinimumSize = new System.Drawing.Size(0, 20);
            this.lblGeciken.Name = "lblGeciken";
            this.lblGeciken.Size = new System.Drawing.Size(182, 20);
            this.lblGeciken.TabIndex = 5;
            this.lblGeciken.Text = "0";
            this.lblGeciken.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvKitaplar
            // 
            this.dgvKitaplar.AllowUserToAddRows = false;
            this.dgvKitaplar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvKitaplar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvKitaplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKitaplar.EnableHeadersVisualStyles = false;
            this.dgvKitaplar.Location = new System.Drawing.Point(12, 156);
            this.dgvKitaplar.MultiSelect = false;
            this.dgvKitaplar.Name = "dgvKitaplar";
            this.dgvKitaplar.ReadOnly = true;
            this.dgvKitaplar.RowHeadersVisible = false;
            this.dgvKitaplar.RowHeadersWidth = 51;
            this.dgvKitaplar.RowTemplate.Height = 24;
            this.dgvKitaplar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvKitaplar.Size = new System.Drawing.Size(809, 167);
            this.dgvKitaplar.TabIndex = 6;
            this.dgvKitaplar.SelectionChanged += new System.EventHandler(this.dgvKitaplar_SelectionChanged);
            // 
            // lblMod
            // 
            this.lblMod.AutoSize = true;
            this.lblMod.Location = new System.Drawing.Point(181, 23);
            this.lblMod.Name = "lblMod";
            this.lblMod.Size = new System.Drawing.Size(51, 16);
            this.lblMod.TabIndex = 12;
            this.lblMod.Text = "MOD : -";
            // 
            // btnKitapEkle
            // 
            this.btnKitapEkle.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnKitapEkle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKitapEkle.FlatAppearance.BorderSize = 0;
            this.btnKitapEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKitapEkle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKitapEkle.ForeColor = System.Drawing.Color.White;
            this.btnKitapEkle.Location = new System.Drawing.Point(139, 33);
            this.btnKitapEkle.Name = "btnKitapEkle";
            this.btnKitapEkle.Size = new System.Drawing.Size(126, 37);
            this.btnKitapEkle.TabIndex = 13;
            this.btnKitapEkle.Text = "Kitap Ekle";
            this.btnKitapEkle.UseVisualStyleBackColor = false;
            this.btnKitapEkle.Click += new System.EventHandler(this.btnKitapEkle_Click);
            // 
            // btnKitapSil
            // 
            this.btnKitapSil.BackColor = System.Drawing.Color.Crimson;
            this.btnKitapSil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKitapSil.FlatAppearance.BorderSize = 0;
            this.btnKitapSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKitapSil.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKitapSil.ForeColor = System.Drawing.Color.White;
            this.btnKitapSil.Location = new System.Drawing.Point(271, 33);
            this.btnKitapSil.Name = "btnKitapSil";
            this.btnKitapSil.Size = new System.Drawing.Size(126, 37);
            this.btnKitapSil.TabIndex = 14;
            this.btnKitapSil.Text = "Kitap Sil";
            this.btnKitapSil.UseVisualStyleBackColor = false;
            this.btnKitapSil.Click += new System.EventHandler(this.btnKitapSil_Click);
            // 
            // btnVerileriSifirla
            // 
            this.btnVerileriSifirla.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnVerileriSifirla.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerileriSifirla.FlatAppearance.BorderSize = 0;
            this.btnVerileriSifirla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerileriSifirla.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnVerileriSifirla.ForeColor = System.Drawing.Color.White;
            this.btnVerileriSifirla.Location = new System.Drawing.Point(535, 33);
            this.btnVerileriSifirla.Name = "btnVerileriSifirla";
            this.btnVerileriSifirla.Size = new System.Drawing.Size(126, 37);
            this.btnVerileriSifirla.TabIndex = 15;
            this.btnVerileriSifirla.Text = "Verileri Sıfırla";
            this.btnVerileriSifirla.UseVisualStyleBackColor = false;
            this.btnVerileriSifirla.Click += new System.EventHandler(this.btnVerileriSifirla_Click);
            // 
            // btnSonIslemler
            // 
            this.btnSonIslemler.BackColor = System.Drawing.SystemColors.ControlText;
            this.btnSonIslemler.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSonIslemler.FlatAppearance.BorderSize = 0;
            this.btnSonIslemler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSonIslemler.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSonIslemler.ForeColor = System.Drawing.Color.White;
            this.btnSonIslemler.Location = new System.Drawing.Point(403, 33);
            this.btnSonIslemler.Name = "btnSonIslemler";
            this.btnSonIslemler.Size = new System.Drawing.Size(126, 37);
            this.btnSonIslemler.TabIndex = 16;
            this.btnSonIslemler.Text = "Son İşlemler";
            this.btnSonIslemler.UseVisualStyleBackColor = false;
            this.btnSonIslemler.Click += new System.EventHandler(this.btnSonIslemler_Click);
            // 
            // grpRol
            // 
            this.grpRol.BackColor = System.Drawing.Color.Bisque;
            this.grpRol.Controls.Add(this.rbYonetici);
            this.grpRol.Controls.Add(this.rbKullanici);
            this.grpRol.Controls.Add(this.lblMod);
            this.grpRol.Location = new System.Drawing.Point(12, 12);
            this.grpRol.Name = "grpRol";
            this.grpRol.Size = new System.Drawing.Size(384, 56);
            this.grpRol.TabIndex = 17;
            this.grpRol.TabStop = false;
            this.grpRol.Text = "Rol Seçimi";
            // 
            // rbYonetici
            // 
            this.rbYonetici.AutoSize = true;
            this.rbYonetici.Location = new System.Drawing.Point(89, 21);
            this.rbYonetici.Name = "rbYonetici";
            this.rbYonetici.Size = new System.Drawing.Size(76, 20);
            this.rbYonetici.TabIndex = 19;
            this.rbYonetici.Text = "Yönetici";
            this.rbYonetici.UseVisualStyleBackColor = true;
            this.rbYonetici.CheckedChanged += new System.EventHandler(this.rbYonetici_CheckedChanged);
            // 
            // rbKullanici
            // 
            this.rbKullanici.AutoSize = true;
            this.rbKullanici.Checked = true;
            this.rbKullanici.Location = new System.Drawing.Point(6, 21);
            this.rbKullanici.Name = "rbKullanici";
            this.rbKullanici.Size = new System.Drawing.Size(77, 20);
            this.rbKullanici.TabIndex = 18;
            this.rbKullanici.TabStop = true;
            this.rbKullanici.Text = "Kullanıcı";
            this.rbKullanici.UseVisualStyleBackColor = true;
            this.rbKullanici.CheckedChanged += new System.EventHandler(this.rbKullanici_CheckedChanged);
            // 
            // txtKitapAdi
            // 
            this.txtKitapAdi.Location = new System.Drawing.Point(537, 31);
            this.txtKitapAdi.Name = "txtKitapAdi";
            this.txtKitapAdi.Size = new System.Drawing.Size(171, 22);
            this.txtKitapAdi.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(406, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "Seçili Kitap Adı :";
            // 
            // lblToplamText
            // 
            this.lblToplamText.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblToplamText.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblToplamText.Location = new System.Drawing.Point(0, 0);
            this.lblToplamText.Name = "lblToplamText";
            this.lblToplamText.Size = new System.Drawing.Size(180, 22);
            this.lblToplamText.TabIndex = 20;
            this.lblToplamText.Text = "Toplam Kitap Sayısı";
            this.lblToplamText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRaftaText
            // 
            this.lblRaftaText.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRaftaText.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblRaftaText.Location = new System.Drawing.Point(0, 0);
            this.lblRaftaText.Name = "lblRaftaText";
            this.lblRaftaText.Size = new System.Drawing.Size(180, 22);
            this.lblRaftaText.TabIndex = 21;
            this.lblRaftaText.Text = "Raftaki Kitap Sayısı";
            this.lblRaftaText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOduncteText
            // 
            this.lblOduncteText.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblOduncteText.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblOduncteText.Location = new System.Drawing.Point(0, 0);
            this.lblOduncteText.Name = "lblOduncteText";
            this.lblOduncteText.Size = new System.Drawing.Size(180, 22);
            this.lblOduncteText.TabIndex = 22;
            this.lblOduncteText.Text = "Ödünçteki Kitap Sayısı";
            this.lblOduncteText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGecikmisText
            // 
            this.lblGecikmisText.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblGecikmisText.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGecikmisText.Location = new System.Drawing.Point(0, 0);
            this.lblGecikmisText.Name = "lblGecikmisText";
            this.lblGecikmisText.Size = new System.Drawing.Size(182, 22);
            this.lblGecikmisText.TabIndex = 23;
            this.lblGecikmisText.Text = "Gecikmiş Kitap Sayısı";
            this.lblGecikmisText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bgOzet
            // 
            this.bgOzet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bgOzet.Controls.Add(this.tlpOzet);
            this.bgOzet.Location = new System.Drawing.Point(12, 55);
            this.bgOzet.Name = "bgOzet";
            this.bgOzet.Size = new System.Drawing.Size(812, 95);
            this.bgOzet.TabIndex = 24;
            this.bgOzet.TabStop = false;
            this.bgOzet.Text = "Özet";
            // 
            // tlpOzet
            // 
            this.tlpOzet.BackColor = System.Drawing.Color.LightGray;
            this.tlpOzet.ColumnCount = 4;
            this.tlpOzet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpOzet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpOzet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpOzet.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpOzet.Controls.Add(this.pnlToplam, 0, 0);
            this.tlpOzet.Controls.Add(this.pnlGecikmis, 3, 0);
            this.tlpOzet.Controls.Add(this.pnlRafta, 1, 0);
            this.tlpOzet.Controls.Add(this.pnlOdunc, 2, 0);
            this.tlpOzet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpOzet.Location = new System.Drawing.Point(3, 18);
            this.tlpOzet.Margin = new System.Windows.Forms.Padding(0);
            this.tlpOzet.Name = "tlpOzet";
            this.tlpOzet.Padding = new System.Windows.Forms.Padding(10);
            this.tlpOzet.RowCount = 1;
            this.tlpOzet.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpOzet.Size = new System.Drawing.Size(806, 74);
            this.tlpOzet.TabIndex = 28;
            // 
            // pnlToplam
            // 
            this.pnlToplam.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlToplam.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlToplam.Controls.Add(this.lblToplamText);
            this.pnlToplam.Controls.Add(this.lblToplam);
            this.pnlToplam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlToplam.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pnlToplam.Location = new System.Drawing.Point(16, 16);
            this.pnlToplam.Margin = new System.Windows.Forms.Padding(6);
            this.pnlToplam.Name = "pnlToplam";
            this.pnlToplam.Size = new System.Drawing.Size(184, 42);
            this.pnlToplam.TabIndex = 24;
            // 
            // pnlGecikmis
            // 
            this.pnlGecikmis.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlGecikmis.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlGecikmis.Controls.Add(this.lblGecikmisText);
            this.pnlGecikmis.Controls.Add(this.lblGeciken);
            this.pnlGecikmis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGecikmis.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pnlGecikmis.Location = new System.Drawing.Point(604, 16);
            this.pnlGecikmis.Margin = new System.Windows.Forms.Padding(6);
            this.pnlGecikmis.Name = "pnlGecikmis";
            this.pnlGecikmis.Size = new System.Drawing.Size(186, 42);
            this.pnlGecikmis.TabIndex = 27;
            // 
            // pnlRafta
            // 
            this.pnlRafta.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlRafta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRafta.Controls.Add(this.lblRaftaText);
            this.pnlRafta.Controls.Add(this.lblRafta);
            this.pnlRafta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRafta.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pnlRafta.Location = new System.Drawing.Point(212, 16);
            this.pnlRafta.Margin = new System.Windows.Forms.Padding(6);
            this.pnlRafta.Name = "pnlRafta";
            this.pnlRafta.Size = new System.Drawing.Size(184, 42);
            this.pnlRafta.TabIndex = 25;
            // 
            // pnlOdunc
            // 
            this.pnlOdunc.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlOdunc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlOdunc.Controls.Add(this.lblOduncteText);
            this.pnlOdunc.Controls.Add(this.lblOduncte);
            this.pnlOdunc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOdunc.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pnlOdunc.Location = new System.Drawing.Point(408, 16);
            this.pnlOdunc.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOdunc.Name = "pnlOdunc";
            this.pnlOdunc.Size = new System.Drawing.Size(184, 42);
            this.pnlOdunc.TabIndex = 26;
            // 
            // btnIadeEt
            // 
            this.btnIadeEt.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnIadeEt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIadeEt.FlatAppearance.BorderSize = 0;
            this.btnIadeEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIadeEt.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIadeEt.ForeColor = System.Drawing.Color.White;
            this.btnIadeEt.Location = new System.Drawing.Point(492, 29);
            this.btnIadeEt.Name = "btnIadeEt";
            this.btnIadeEt.Size = new System.Drawing.Size(98, 39);
            this.btnIadeEt.TabIndex = 9;
            this.btnIadeEt.Text = "İade Et";
            this.btnIadeEt.UseVisualStyleBackColor = false;
            this.btnIadeEt.Click += new System.EventHandler(this.btnIadeEt_Click);
            // 
            // btnListele
            // 
            this.btnListele.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btnListele.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListele.FlatAppearance.BorderSize = 0;
            this.btnListele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListele.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListele.ForeColor = System.Drawing.Color.White;
            this.btnListele.Location = new System.Drawing.Point(214, 29);
            this.btnListele.Name = "btnListele";
            this.btnListele.Size = new System.Drawing.Size(105, 39);
            this.btnListele.TabIndex = 7;
            this.btnListele.Text = "Listele";
            this.btnListele.UseVisualStyleBackColor = false;
            this.btnListele.Click += new System.EventHandler(this.btnListele_Click);
            // 
            // btnOduncAl
            // 
            this.btnOduncAl.BackColor = System.Drawing.Color.Gold;
            this.btnOduncAl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOduncAl.FlatAppearance.BorderSize = 0;
            this.btnOduncAl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOduncAl.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOduncAl.ForeColor = System.Drawing.Color.White;
            this.btnOduncAl.Location = new System.Drawing.Point(347, 29);
            this.btnOduncAl.Name = "btnOduncAl";
            this.btnOduncAl.Size = new System.Drawing.Size(118, 39);
            this.btnOduncAl.TabIndex = 8;
            this.btnOduncAl.Text = "Ödünç Al";
            this.btnOduncAl.UseVisualStyleBackColor = false;
            this.btnOduncAl.Click += new System.EventHandler(this.btnOduncAl_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.btnOduncAl);
            this.groupBox1.Controls.Add(this.btnListele);
            this.groupBox1.Controls.Add(this.btnIadeEt);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(12, 329);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(809, 80);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kullanıcı Linkleri";
            // 
            // grbYoneticiLinkleri
            // 
            this.grbYoneticiLinkleri.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grbYoneticiLinkleri.Controls.Add(this.btnKitapSil);
            this.grbYoneticiLinkleri.Controls.Add(this.btnSonIslemler);
            this.grbYoneticiLinkleri.Controls.Add(this.btnVerileriSifirla);
            this.grbYoneticiLinkleri.Controls.Add(this.btnKitapEkle);
            this.grbYoneticiLinkleri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.grbYoneticiLinkleri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grbYoneticiLinkleri.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grbYoneticiLinkleri.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.grbYoneticiLinkleri.Location = new System.Drawing.Point(12, 415);
            this.grbYoneticiLinkleri.Name = "grbYoneticiLinkleri";
            this.grbYoneticiLinkleri.Size = new System.Drawing.Size(809, 86);
            this.grbYoneticiLinkleri.TabIndex = 29;
            this.grbYoneticiLinkleri.TabStop = false;
            this.grbYoneticiLinkleri.Text = "Yönetici Linkleri";
            this.grbYoneticiLinkleri.Visible = false;
            // 
            // txtAra
            // 
            this.txtAra.Location = new System.Drawing.Point(537, 6);
            this.txtAra.Name = "txtAra";
            this.txtAra.Size = new System.Drawing.Size(171, 22);
            this.txtAra.TabIndex = 30;
            this.txtAra.TextChanged += new System.EventHandler(this.txtAra_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(406, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 16);
            this.label2.TabIndex = 31;
            this.label2.Text = "Kitap Adını Yaz :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(893, 522);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAra);
            this.Controls.Add(this.grbYoneticiLinkleri);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bgOzet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtKitapAdi);
            this.Controls.Add(this.grpRol);
            this.Controls.Add(this.dgvKitaplar);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kütüphane Kontrol Sistemi";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKitaplar)).EndInit();
            this.grpRol.ResumeLayout(false);
            this.grpRol.PerformLayout();
            this.bgOzet.ResumeLayout(false);
            this.tlpOzet.ResumeLayout(false);
            this.pnlToplam.ResumeLayout(false);
            this.pnlGecikmis.ResumeLayout(false);
            this.pnlRafta.ResumeLayout(false);
            this.pnlOdunc.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.grbYoneticiLinkleri.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblToplam;
        private System.Windows.Forms.Label lblRafta;
        private System.Windows.Forms.Label lblOduncte;
        private System.Windows.Forms.Label lblGeciken;
        private System.Windows.Forms.DataGridView dgvKitaplar;
        private System.Windows.Forms.Label lblMod;
        private System.Windows.Forms.Button btnKitapEkle;
        private System.Windows.Forms.Button btnKitapSil;
        private System.Windows.Forms.Button btnVerileriSifirla;
        private System.Windows.Forms.Button btnSonIslemler;
        private System.Windows.Forms.GroupBox grpRol;
        private System.Windows.Forms.RadioButton rbKullanici;
        private System.Windows.Forms.RadioButton rbYonetici;
        private System.Windows.Forms.TextBox txtKitapAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblToplamText;
        private System.Windows.Forms.Label lblRaftaText;
        private System.Windows.Forms.Label lblOduncteText;
        private System.Windows.Forms.Label lblGecikmisText;
        private System.Windows.Forms.GroupBox bgOzet;
        private System.Windows.Forms.Panel pnlToplam;
        private System.Windows.Forms.Panel pnlGecikmis;
        private System.Windows.Forms.Panel pnlOdunc;
        private System.Windows.Forms.Panel pnlRafta;
        private System.Windows.Forms.TableLayoutPanel tlpOzet;
        private System.Windows.Forms.Button btnIadeEt;
        private System.Windows.Forms.Button btnListele;
        private System.Windows.Forms.Button btnOduncAl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox grbYoneticiLinkleri;
        private System.Windows.Forms.TextBox txtAra;
        private System.Windows.Forms.Label label2;
    }
}

