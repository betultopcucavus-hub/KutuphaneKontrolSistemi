﻿using Kutuphane.Core;
using System;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Kutuphane.WinForms
{
    public partial class Form1 : Form
    {
        private Rol _aktifRol = Rol.User;
        private LibraryService _service;

        private const string AdminSifre = "9999";
        private bool _adminDogru = false;

        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var dosyaYolu = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "kitapla.txt");
                      
            _service = new LibraryService(dosyaYolu);
            _service.BaslangicYukleVeyaOlustur();

            rbKullanici.Checked = true;
            _aktifRol = Rol.User;

            RolUygula();
            YenileOzet();
            YenileGrid(txtAra.Text);
        }

        private void RolUygula()
        {

            if (_aktifRol == Rol.User)
            {
                //user mod için
                btnKitapEkle.Visible = false;
                btnKitapSil.Visible = false;
                btnVerileriSifirla.Visible = false;
                btnSonIslemler.Visible = false;
                grbYoneticiLinkleri.Visible = false;

                lblMod.Text = " MOD : User";
            }
            else if (_aktifRol == Rol.Admin)
            {
                // admin mod için
                btnKitapEkle.Visible = true;
                btnKitapSil.Visible = true;
                btnVerileriSifirla.Visible = true;
                btnSonIslemler.Visible = true;
                grbYoneticiLinkleri.Visible = true;

                lblMod.Text = " MOD : Admin";
            }

        }
        private void rbKullanici_CheckedChanged(object sender, EventArgs e)
        {
            if (!rbKullanici.Checked)
                return;
            {
                _adminDogru = false;
                _aktifRol = Rol.User;
                lblMod.Text = " MOD : User";
                RolUygula();
                YenileGrid(txtAra.Text);
                YenileOzet();
            }
        }

        private void rbYonetici_CheckedChanged(object sender, EventArgs e)
        {

            // sadece "işaretlenince" çalışşsın, kaldırınca değil..
            if (!rbYonetici.Checked)
                return;           

            using (var frm = new FrmAdminSifre())
            {
                if(frm.ShowDialog() == DialogResult.OK)
                {
                    if(frm.GirilenSifre == AdminSifre) // 9999
                    {
                        _aktifRol = Rol.Admin;
                        RolUygula();
                        YenileGrid(txtAra.Text);
                        YenileOzet();
                    }
                    else
                    {
                        MessageBox.Show("Şifre yanlış.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                       //geri kullanıcaya dönmek için
                        rbKullanici.Checked = true;
                    }
                }
                else
                {
                    rbKullanici.Checked = true; //iptal ederse
                }
            }          
        }
        private void YenileOzet()
        {
            var o = _service.Ozet();

            lblToplam.Text = o.toplam.ToString();
            lblRafta.Text = o.rafta.ToString();
            lblOduncte.Text = o.oduncte.ToString();
            lblGeciken.Text = o.geciken.ToString();

            // geciken varsa kırmızı vibe
            lblGeciken.ForeColor = (o.geciken > 0) ? Color.IndianRed : Color.SeaGreen;
        }

        private void YenileGrid(string arama)
        {
            if (_service == null) return;

            bool adminMi = rbYonetici.Checked;
            //servisten kitapları almak için,
            var kitaplar = _service.GetAll();

            if(!string.IsNullOrWhiteSpace(arama))
            {
                kitaplar = kitaplar.Where(k => k.Ad.IndexOf(arama, StringComparison.CurrentCultureIgnoreCase) >= 0).ToList();
            }

            //grid'e basılacak liste (maskeli)
            var liste = kitaplar.Select(k => new
            {
                KitapAdi    = k.Ad,
                Durum       = k.OduncteMi ? "Ödünçte" : "Rafta",

                AlanKisi    = adminMi ? k.AlanKisi :"****", 
                           
                OduncTarihi = k.OduncTarihi.HasValue
                            ? (adminMi ? k.OduncTarihi.Value.ToString("dd.MM.yyyy HH:mm") : "****")
                            : "-",

                GecikmisMi = adminMi && k.GeciktiMi(_service.GecikmeGunSiniri)
            }).ToList();


            //Grid reset + bas
            dgvKitaplar.DataSource = null;
            dgvKitaplar.AutoGenerateColumns = true;
            dgvKitaplar.DataSource = liste;
            dgvKitaplar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // admin değilse gecikme kolonunu gizleyelim
            var colGecikme = dgvKitaplar.Columns["GecikmisMi"];
            if (colGecikme != null)
                colGecikme.Visible = adminMi;

            //GEcikenleri kırmızı yapmak için
            foreach (DataGridViewRow row in dgvKitaplar.Rows)
            {
                if (row.IsNewRow) continue;

                bool gecikmis = false;
                //kolon adı : GecikmisMi
                var cell = row.Cells["GecikmisMi"];
                if (cell != null && cell.Value != null)
                    bool.TryParse(cell.Value.ToString(), out gecikmis);

                if(gecikmis)
                {
                    row.DefaultCellStyle.ForeColor = Color.IndianRed;
                    row.DefaultCellStyle.Font = new Font(dgvKitaplar.Font, FontStyle.Bold);
                }
            }
            // özet sayılar için
            lblToplam.Text = kitaplar.Count.ToString();
            lblRafta.Text = kitaplar.Count(k => !k.OduncteMi).ToString();
            lblOduncte.Text = kitaplar.Count(k => k.OduncteMi).ToString();
            lblGeciken.Text = kitaplar.Count(k => k.GeciktiMi(_service.GecikmeGunSiniri)).ToString();
        }
                  


        private void btnListele_Click(object sender, EventArgs e)
        {
            YenileGrid(txtAra.Text);
            YenileOzet();
        }

        private void btnOduncAl_Click(object sender, EventArgs e)
        {
            var kitapAdi = txtKitapAdi.Text?.Trim(); //text adı boşsa uyarmak için
            if( string.IsNullOrWhiteSpace(kitapAdi ) )
            {
                MessageBox.Show("Önce listeden bir kitap seç.", "Uyarı");
                return;
            }

            //kitabı alan kişiden InputBox ile ismini almak için
            string alanKisi = Interaction.InputBox("Kitabı kim aldı?", "Ödünç Al", "");
            alanKisi = alanKisi?.Trim();

            if(string.IsNullOrWhiteSpace(alanKisi) )
            {
                MessageBox.Show("Alan kişi boş olamaz!", "Uyarı");
                return;
            }

            string mesaj;
            bool ok =_service.OduncAl(kitapAdi, alanKisi, out mesaj);
            MessageBox.Show(mesaj, ok ? "OK" : "Hata");

            YenileGrid(txtAra.Text);
            YenileOzet();
        }

        private void btnIadeEt_Click(object sender, EventArgs e)
        {
            var kitapAdi = txtKitapAdi.Text?.Trim(); //seçili kitabı kontrol etmek için
            if(string.IsNullOrWhiteSpace(kitapAdi))
            {
                MessageBox.Show("Önce listeden bir katap seç.", "Uyarı");
                  return;
            }
            
            string mesaj;
            bool ok = _service.IadeEt(kitapAdi, out mesaj);
            MessageBox.Show(mesaj, ok ? " OK": "Hata");

            YenileGrid(txtAra.Text);
            YenileOzet();
        }

        private void btnKitapEkle_Click(object sender, EventArgs e)
        {
            if(!rbYonetici.Checked)  // admin değilse engellemek için
            {
                MessageBox.Show("Bu işlem sadece yönetici içindir.", "Yetki");
                return;
            }

            //eklenecek olan kitap adını girmek için InputBox koydum
            string yeniAd = Interaction.InputBox("Eklenecek Kitap adı :", "Kitap ekle", "");
            yeniAd = yeniAd.Trim();

            if (string.IsNullOrWhiteSpace(yeniAd))
            {
                MessageBox.Show("Kitap adı boş olamaz!", "Uyarı");
                return;
            }

            string mesaj;
            bool ok = _service.KitapEkle(yeniAd, out mesaj);
            txtKitapAdi.Clear();
            MessageBox.Show(mesaj, ok ? " OK": "Hata");

            YenileGrid(txtAra.Text);
            YenileOzet();
        }

        private void btnKitapSil_Click(object sender, EventArgs e)
        {
           if(!rbYonetici.Checked)  // admin kontrolü için 
            {
                MessageBox.Show("Bu işlem sadece yönetici içindir.", "Yetki");
                return;
            }

            var kitapAdi = txtKitapAdi.Text?.Trim(); //seçili kitap kontrolu
            if(string.IsNullOrWhiteSpace(kitapAdi))
            {
                MessageBox.Show("Silmek için listeden bir kaitap seç", "Uyarı");
                return;
            }

            var soru = MessageBox.Show($"'{kitapAdi}' silinsin mi?", "Onay", MessageBoxButtons.YesNo); //emin misin yes-no
            if (soru != DialogResult.Yes)
                return;

            string mesaj;
            bool ok =_service.KitapSil(kitapAdi, out mesaj);


            YenileGrid(txtAra.Text);
            YenileOzet();
        }

        private void btnSonIslemler_Click(object sender, EventArgs e)
        {
            if (!rbYonetici.Checked) //admin kontrol
            {
                MessageBox.Show("Bu ekran sadece yönetici içindir", "Yetki");
                return;
            }

            var loglar = _service.SonLoglariGetir(20); // son 20 satır
            string metin =(loglar ==  null || loglar.Count == 0)
                ? "Henüz log yok!"
                : string.Join(Environment.NewLine, loglar);

            MessageBox.Show(metin, "Son İşlemler");
        }

        private void btnVerileriSifirla_Click(object sender, EventArgs e)
        {
            if (!rbYonetici.Checked) //admin kontrol
            {
                MessageBox.Show("Bu ekran sadece yönetici içindir", "Yetki");
                return;
            }

            var soru = MessageBox.Show("TÜM veriler silinecek. Emin misin?", "Dikkat", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (soru != DialogResult.Yes) return;
            {
                _service.VerileriSifirla();
                MessageBox.Show("Veriler sıfırlandı!", "OK");

                YenileGrid(txtAra.Text);
                YenileOzet();
            }
        }

        private void dgvKitaplar_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvKitaplar.CurrentRow == null) return;
            if (dgvKitaplar.CurrentRow.IsNewRow) return;

            var cell = dgvKitaplar.CurrentRow.Cells["KitapAdi"];
            if (cell == null) return;
            txtKitapAdi.Text =Convert.ToString(cell.Value);
        }

        private void txtAra_TextChanged(object sender, EventArgs e)
        {
            YenileGrid(txtAra.Text);
        }
    }
}
